// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

// Custom exception derived from std::exception
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Victoria's Custom Exception";
    }
};

bool do_even_more_custom_application_logic()
{
    //Throw a standard exception
    throw std::runtime_error("Standard Exception");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    //Wrapped the call to do_even_more_custom_application_logic() with an exception handler that catches std::exception, displays a message and the exception.what(), then continues processing
    try
    {
        do_even_more_custom_application_logic();
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Exception caught: " << exception.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0)
    {
        // Throw a divide by zero exception using a standard C++ defined exception
        throw std::runtime_error("Divide by zero exception");
    }

    return (num / den);
}

void do_division() noexcept
{
    //Exception handler to capture ONLY the exception thrown by divide
    try
    {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Exception caught: " << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& exception)
    {
        std::cout << "Custom Exception caught: " << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Standard Exception caught: " << exception.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Unhandled Exception caught." << std::endl;
    }

    return 0;
}